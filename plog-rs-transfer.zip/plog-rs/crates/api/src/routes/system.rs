//! 系统维护路由

use axum::{extract::State, routing::get, Json, Router};

use crate::AppState;
use plog_auth::AuthUser;
use plog_contracts::ApiResponse;

fn theme_discover_error_code(err: &plog_theme::ThemeError) -> &'static str {
    match err {
        plog_theme::ThemeError::Timeout(_) => "THEME_DISCOVER_TIMEOUT",
        _ => "THEME_DISCOVER_FAILED",
    }
}

fn plugin_discover_error_code(err: &plog_plugin::PluginError) -> &'static str {
    match err {
        plog_plugin::PluginError::Timeout(_) => "PLUGIN_DISCOVER_TIMEOUT",
        _ => "PLUGIN_DISCOVER_FAILED",
    }
}

/// 创建系统维护路由
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/system/discover/themes", get(discover_themes))
        .route("/api/system/discover/plugins", get(discover_plugins))
}

async fn discover_themes(
    State(state): State<AppState>,
    user: AuthUser,
) -> Json<ApiResponse<serde_json::Value>> {
    if !user.is_admin() {
        return Json(ApiResponse::error("PERMISSION_DENIED", "Admin role required"));
    }

    let mut manager = plog_theme::ThemeManager::new(state.theme_dir.clone());
    match manager.discover_async_with_timeout().await {
        Ok(items) => Json(ApiResponse::success(serde_json::json!({
            "count": items.len(),
            "items": items
        }))),
        Err(e) => Json(ApiResponse::error(theme_discover_error_code(&e), e.to_string())),
    }
}

async fn discover_plugins(
    State(state): State<AppState>,
    user: AuthUser,
) -> Json<ApiResponse<serde_json::Value>> {
    if !user.is_admin() {
        return Json(ApiResponse::error("PERMISSION_DENIED", "Admin role required"));
    }

    let mut manager = plog_plugin::PluginManager::new(state.plugin_dir.clone());
    match manager.discover_async_with_timeout().await {
        Ok(items) => Json(ApiResponse::success(serde_json::json!({
            "count": items.len(),
            "items": items
        }))),
        Err(e) => Json(ApiResponse::error(plugin_discover_error_code(&e), e.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_theme_discover_error_code_mapping() {
        let timeout_err = plog_theme::ThemeError::Timeout("timed out".to_string());
        let io_err = plog_theme::ThemeError::Io {
            path: std::path::PathBuf::from("themes"),
            source: std::io::Error::other("io"),
        };

        assert_eq!(theme_discover_error_code(&timeout_err), "THEME_DISCOVER_TIMEOUT");
        assert_eq!(theme_discover_error_code(&io_err), "THEME_DISCOVER_FAILED");
    }

    #[test]
    fn test_plugin_discover_error_code_mapping() {
        let timeout_err = plog_plugin::PluginError::Timeout("timed out".to_string());
        let io_err = plog_plugin::PluginError::Io {
            path: std::path::PathBuf::from("plugins"),
            source: std::io::Error::other("io"),
        };

        assert_eq!(plugin_discover_error_code(&timeout_err), "PLUGIN_DISCOVER_TIMEOUT");
        assert_eq!(plugin_discover_error_code(&io_err), "PLUGIN_DISCOVER_FAILED");
    }
}
