# Plog Async I/O Migration Plan

## Goal

Migrate file-system heavy modules to async-safe implementations when they are invoked from request paths, while keeping behavior unchanged and avoiding runtime stalls.

## Current State

- `crates/theme` and `crates/plugin` still use `std::fs` in manager and manifest loading paths.
- These APIs are synchronous today. They are safe in CLI/startup flows, but become risky if called directly inside `axum` handlers.
- Most hot request paths are database async operations and are already runtime-friendly.

## Migration Triggers

Start migration when any of the following happens:

- Theme/plugin discovery or uninstall is called inside HTTP handlers.
- P95 request latency rises and traces show long filesystem spans.
- Plugin/theme count grows enough to make directory scans noticeable.

## Strategy

### Phase 1: Interface Split (low risk)

- Keep existing sync API for startup tasks.
- Introduce async variants:
  - `ThemeManager::discover_async()`
  - `ThemeManager::uninstall_theme_async()`
  - `PluginManager::discover_async()`
  - `PluginManager::uninstall_plugin_async()`
- Internally use `tokio::fs::{read_dir, read_to_string, remove_dir_all}`.

### Phase 2: Handler Integration

- If called from routes, switch to async variants only.
- Add `tracing` spans around filesystem operations with path and elapsed time.
- Enforce timeout for long directory scans:
  - `tokio::time::timeout(Duration::from_secs(2), manager.discover_async())`

### Phase 3: Performance Hardening

- Cache discovery results with explicit invalidation on install/uninstall.
- Use incremental refresh (watch mode) instead of full scan per request.
- For CPU-heavy parsing batches, isolate with `tokio::task::spawn_blocking`.

## Coding Rules

- No `std::fs` inside `async fn` that can run on request workers.
- No lock guard held across `.await`.
- All I/O errors must include `path` context.
- No `unwrap/expect` in runtime code paths.

## Suggested Refactor Targets

- `crates/theme/src/manager.rs`
- `crates/theme/src/types.rs`
- `crates/plugin/src/manager.rs`
- `crates/plugin/src/types.rs`

## Validation Checklist

- `cargo test -p plog-theme -p plog-plugin`
- `cargo test -p plog-api`
- Load test with concurrent requests hitting plugin/theme endpoints.
- Confirm no blocking spans in runtime traces.
- Verify uninstall/discover behavior parity with baseline.

## Rollback Plan

- Keep old sync methods for one release cycle.
- Gate async path by feature flag: `async-fs`.
- Roll back by disabling feature flag if production latency regresses.
